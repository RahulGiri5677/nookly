import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// ─── Shared AI call with 5-second timeout ────────────────────────────────────

async function callAI(messages: { role: string; content: string }[], tools?: unknown[]): Promise<unknown> {
  const apiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!apiKey) throw new Error("AI gateway not configured");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const body: Record<string, unknown> = {
      model: "google/gemini-3-flash-preview",
      messages,
    };
    if (tools) {
      body.tools = tools;
      body.tool_choice = "auto";
    }

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`AI gateway error ${res.status}: ${txt}`);
    }

    return await res.json();
  } finally {
    clearTimeout(timeout);
  }
}

// ─── Handlers ────────────────────────────────────────────────────────────────

async function handleIcebreakerSuggestions(topic: string) {
  const tools = [
    {
      type: "function",
      function: {
        name: "return_suggestions",
        description: "Return 3 icebreaker suggestions",
        parameters: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: { type: "string" },
              minItems: 3,
              maxItems: 3,
            },
          },
          required: ["suggestions"],
        },
      },
    },
  ];

  const result = await callAI(
    [
      {
        role: "system",
        content:
          "You help generate gentle, inclusive icebreaker questions for small in-person group meetups. " +
          "Keep tone calm, friendly, and not performative. Avoid personal, political, or sensitive topics. " +
          "Generate 3 short conversation starters based on the topic. Each should be one sentence.",
      },
      { role: "user", content: `Topic: ${topic}` },
    ],
    tools
  ) as any;

  const toolCall = result?.choices?.[0]?.message?.tool_calls?.[0];
  if (toolCall?.function?.arguments) {
    const parsed = JSON.parse(toolCall.function.arguments);
    return { suggestions: parsed.suggestions };
  }

  // Fallback: try to parse content
  const content = result?.choices?.[0]?.message?.content || "";
  const match = content.match(/\[[\s\S]*\]/);
  if (match) {
    return { suggestions: JSON.parse(match[0]) };
  }

  throw new Error("Could not parse suggestions");
}

async function handleTopicRefinement(rawTopic: string) {
  const VALID_CATEGORIES = ["Coffee", "Walk", "Books", "Art", "Music", "Discussion", "Learning"];

  const tools = [
    {
      type: "function",
      function: {
        name: "return_refinement",
        description: "Return refined topic data",
        parameters: {
          type: "object",
          properties: {
            title:       { type: "string" },
            description: { type: "string" },
            category:    { type: "string", enum: VALID_CATEGORIES },
          },
          required: ["title", "description", "category"],
        },
      },
    },
  ];

  const result = await callAI(
    [
      {
        role: "system",
        content:
          "Refine casual meetup topic text into a short clean title (max 6 words), " +
          "a one-line description (max 12 words), and recommend one category from: " +
          VALID_CATEGORIES.join(", ") + ". Keep tone warm and simple.",
      },
      { role: "user", content: `Raw topic: ${rawTopic}` },
    ],
    tools
  ) as any;

  const toolCall = result?.choices?.[0]?.message?.tool_calls?.[0];
  if (toolCall?.function?.arguments) {
    return JSON.parse(toolCall.function.arguments);
  }
  throw new Error("Could not parse topic refinement");
}

async function handleModerationCheck(comment: string): Promise<{
  severity: "safe" | "mild" | "high";
  reason: string;
}> {
  const tools = [
    {
      type: "function",
      function: {
        name: "return_moderation",
        description: "Return moderation result",
        parameters: {
          type: "object",
          properties: {
            severity: { type: "string", enum: ["safe", "mild", "high"] },
            reason:   { type: "string" },
          },
          required: ["severity", "reason"],
        },
      },
    },
  ];

  const result = await callAI(
    [
      {
        role: "system",
        content:
          "Analyze this comment for harassment, hate speech, sexual content, threats, " +
          "political recruitment, or MLM promotion. Return severity: safe, mild, or high. " +
          "Provide a short internal reason.",
      },
      { role: "user", content: comment },
    ],
    tools
  ) as any;

  const toolCall = result?.choices?.[0]?.message?.tool_calls?.[0];
  if (toolCall?.function?.arguments) {
    return JSON.parse(toolCall.function.arguments);
  }
  return { severity: "safe", reason: "parse_fallback" };
}

async function handleReflectionPrompt(): Promise<string> {
  const result = await callAI(
    [
      {
        role: "system",
        content:
          "Generate one gentle reflective question for someone who just attended a small in-person " +
          "conversation meetup. Keep it warm, non-intrusive, and short (max 12 words). " +
          "Avoid therapy language. Return only the question text.",
      },
      { role: "user", content: "Generate a reflection prompt." },
    ]
  ) as any;

  const content = result?.choices?.[0]?.message?.content?.trim();
  if (!content) throw new Error("No reflection prompt returned");

  // Strip surrounding quotes if model wrapped it
  return content.replace(/^["']|["']$/g, "");
}

// ─── Main handler ─────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Auth check — only authenticated users can call this
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const userClient  = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) return json({ error: "Unauthorized" }, 401);

    const body = await req.json();
    const { type } = body;

    // ── Route by type ────────────────────────────────────────────────────────

    if (type === "icebreaker_suggestions") {
      const { topic } = body;
      if (!topic || typeof topic !== "string" || topic.length < 3) {
        return json({ error: "Invalid topic" }, 400);
      }
      try {
        const result = await handleIcebreakerSuggestions(topic.slice(0, 200));
        return json(result);
      } catch (e) {
        console.error("icebreaker_suggestions error:", e);
        return json({ suggestions: [] }); // fail silently
      }
    }

    if (type === "topic_refinement") {
      const { raw_topic } = body;
      if (!raw_topic || typeof raw_topic !== "string" || raw_topic.length < 5) {
        return json({ error: "Too short" }, 400);
      }
      try {
        const result = await handleTopicRefinement(raw_topic.slice(0, 300));
        return json(result);
      } catch (e) {
        console.error("topic_refinement error:", e);
        return json(null); // fail silently → caller hides suggestion
      }
    }

    if (type === "moderation_check") {
      const { comment } = body;
      if (!comment || typeof comment !== "string") {
        return json({ severity: "safe", reason: "" });
      }
      try {
        const result = await handleModerationCheck(comment.slice(0, 500));

        // If flagged, log to moderation_logs table
        if (result.severity !== "safe") {
          const adminClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
          await adminClient.from("moderation_logs").insert({
            user_id:   user.id,
            comment:   comment.slice(0, 500),
            severity:  result.severity,
            reason:    result.reason,
          }).maybeSingle(); // fire-and-forget, ignore errors
        }

        // Only return severity to caller — never expose internal reason
        return json({ severity: result.severity });
      } catch (e) {
        console.error("moderation_check error:", e);
        return json({ severity: "safe" }); // fail open (don't block users on AI failure)
      }
    }

    if (type === "reflection_prompt") {
      // Internal use by auto-mark-noshow — service role passes user_id in body
      // We still require auth for direct calls
      try {
        const prompt = await handleReflectionPrompt();
        return json({ prompt });
      } catch (e) {
        console.error("reflection_prompt error:", e);
        return json(null); // fail silently
      }
    }

    return json({ error: "Unknown type" }, 400);
  } catch (err) {
    console.error("ai-nook error:", err);
    return json({ error: "Internal error" }, 500);
  }
});
