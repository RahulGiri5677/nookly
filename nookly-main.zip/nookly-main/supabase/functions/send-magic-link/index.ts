// send-magic-link — Custom branded Magic Link email via Resend
// Bypasses default Supabase auth email entirely.
// Security: INTERNAL_FUNCTION_SECRET not required here (called by frontend).
// Rate limiting is enforced per-email via email_logs cooldown check.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { buildMagicLinkEmail, MAGIC_LINK_SUBJECT, EMAIL_FROM } from "../_shared/emailTemplates.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!RESEND_API_KEY || !SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return new Response(JSON.stringify({ error: "Missing server configuration" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let body: { email?: string };
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const email = (body.email || "").trim().toLowerCase();

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!email || !emailRegex.test(email)) {
    return new Response(
      // Generic response — never reveal whether email exists
      JSON.stringify({ success: true }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const adminClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

  // ── Rate limit: max 1 magic link per email per 60 seconds ──
  const oneMinuteAgo = new Date(Date.now() - 60_000).toISOString();
  const { data: recentLogs } = await adminClient
    .from("email_logs")
    .select("id")
    .eq("email_type", "magic_link")
    .eq("recipient", email)
    .gte("created_at", oneMinuteAgo)
    .limit(1);

  if (recentLogs && recentLogs.length > 0) {
    // Silent success — never leak rate limit info
    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // ── Generate magic link via Supabase Admin API ──
  let magicLink: string;
  try {
    const { data, error } = await adminClient.auth.admin.generateLink({
      type: "magiclink",
      email,
      options: {
        redirectTo: "https://nookly.me/auth/callback",
      },
    });

    if (error || !data?.properties?.action_link) {
      throw new Error(error?.message || "Link generation failed");
    }

    magicLink = data.properties.action_link;
  } catch (err) {
    console.error("Magic link generation error:", err);
    // Log the failure
    await adminClient.from("email_logs").insert({
      email_type: "magic_link",
      recipient: email,
      status: "error",
      error_message: "Link generation failed",
    });
    // Generic success — never reveal backend errors
    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // ── Send via Resend ──
  const html = buildMagicLinkEmail(magicLink);

  let sendStatus = "sent";
  let errorMessage: string | null = null;
  let providerResponse: unknown = null;

  try {
    const resendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: EMAIL_FROM,
        to: [email],
        subject: MAGIC_LINK_SUBJECT,
        html,
      }),
    });

    providerResponse = await resendRes.json();

    if (!resendRes.ok) {
      sendStatus = "error";
      errorMessage = `Resend error: ${resendRes.status}`;
      console.error("Resend failed:", providerResponse);
    }
  } catch (err) {
    sendStatus = "error";
    errorMessage = "Email send failed";
    console.error("Email send error:", err);
  }

  // ── Log to email_logs ──
  await adminClient.from("email_logs").insert({
    email_type: "magic_link",
    recipient: email,
    status: sendStatus,
    error_message: errorMessage,
    provider_response: providerResponse as any,
  });

  // Always return generic success
  return new Response(JSON.stringify({ success: true }), {
    status: 200,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
