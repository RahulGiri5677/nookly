import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const ALLOWED_TABLES = [
  "nooks", "nook_members", "attendance", "profiles", "notifications",
  "feedback", "admin_logs", "email_logs", "feature_flags", "system_events",
  "reports", "user_roles",
];

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return json({ error: "Unauthorized" }, 401);
    }
    const userId = claimsData.claims.sub as string;

    const admin = createClient(supabaseUrl, serviceKey);

    // Verify admin role
    const { data: roleData } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();

    if (!roleData) {
      return json({ error: "Forbidden: Admin only" }, 403);
    }

    const body = await req.json();
    const { action } = body;

    // Log admin action
    await admin.from("system_events").insert({
      event_type: `admin.${action}`,
      source: "founder_dashboard",
      user_id: userId,
      details: body,
    });

    switch (action) {
      case "discover_schema": {
        const { data, error } = await admin.rpc("get_public_schema");
        if (error) throw error;
        return json({ schema: data });
      }

      case "read_table": {
        const { table_name, limit = 50, offset = 0 } = body;
        if (!ALLOWED_TABLES.includes(table_name)) {
          return json({ error: "Table access denied" }, 403);
        }
        if (!/^[a-z_][a-z0-9_]*$/.test(table_name)) {
          return json({ error: "Invalid table name" }, 400);
        }
        const { data, error, count } = await admin
          .from(table_name)
          .select("*", { count: "exact" })
          .order("created_at", { ascending: false })
          .range(offset, offset + limit - 1);
        if (error) throw error;
        return json({ rows: data, total: count });
      }

      case "delete_row": {
        const { table_name, row_id } = body;
        if (!ALLOWED_TABLES.includes(table_name)) {
          return json({ error: "Table access denied" }, 403);
        }
        if (!/^[a-z_][a-z0-9_]*$/.test(table_name)) {
          return json({ error: "Invalid table name" }, 400);
        }
        const { error } = await admin.from(table_name).delete().eq("id", row_id);
        if (error) throw error;
        return json({ success: true });
      }

      case "list_feature_flags": {
        const { data } = await admin.from("feature_flags").select("*").order("name");
        return json({ flags: data || [] });
      }

      case "toggle_feature_flag": {
        const { flag_id, enabled } = body;
        await admin.from("feature_flags").update({
          enabled,
          updated_at: new Date().toISOString(),
        }).eq("id", flag_id);
        return json({ success: true });
      }

      case "create_feature_flag": {
        const { name, description, admin_only } = body;
        const { error } = await admin.from("feature_flags").insert({
          name,
          description: description || "",
          admin_only: admin_only || false,
        });
        if (error) throw error;
        return json({ success: true });
      }

      case "list_events": {
        const { limit = 50, event_type, source } = body;
        let query = admin
          .from("system_events")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(limit);
        if (event_type) query = query.eq("event_type", event_type);
        if (source) query = query.eq("source", source);
        const { data } = await query;

        // Also fetch admin_logs
        const { data: adminLogs } = await admin
          .from("admin_logs")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(limit);

        return json({
          events: data || [],
          admin_logs: adminLogs || [],
        });
      }

      case "list_notification_types": {
        const { data } = await admin
          .from("notifications")
          .select("type")
          .limit(1000);
        const types = [...new Set((data || []).map((n: any) => n.type))];
        return json({ types });
      }

      case "send_test_notification": {
        const { title, message, type, nook_id, nook_title } = body;
        await admin.from("notifications").insert({
          user_id: userId,
          title: title || "Test Notification 🧪",
          message: message || "This is a test notification from Founder Mode.",
          type: type || "update",
          nook_id: nook_id || null,
          nook_title: nook_title || null,
        });
        return json({ success: true });
      }

      case "list_email_logs": {
        const { data } = await admin
          .from("email_logs")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(50);
        return json({ logs: data || [] });
      }

      case "send_test_email": {
        const { to, subject, html } = body;
        const resendKey = Deno.env.get("RESEND_API_KEY");
        if (!resendKey) {
          return json({ error: "RESEND_API_KEY not configured" }, 500);
        }
        try {
          const res = await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${resendKey}`,
            },
            body: JSON.stringify({
              from: "Nook <onboarding@resend.dev>",
              to: [to],
              subject,
              html,
            }),
          });
          const resBody = await res.json();
          // Log the email
          await admin.from("email_logs").insert({
            email_type: "test_email",
            recipient: to,
            status: res.ok ? "sent" : "failed",
            error_message: res.ok ? null : JSON.stringify(resBody),
            provider_response: resBody,
          });
          if (!res.ok) return json({ error: resBody }, 500);
          return json({ success: true, data: resBody });
        } catch (err) {
          await admin.from("email_logs").insert({
            email_type: "test_email",
            recipient: to,
            status: "failed",
            error_message: String(err),
          });
          return json({ error: String(err) }, 500);
        }
      }

      default:
        return json({ error: `Unknown action: ${action}` }, 400);
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("Discovery error:", msg);
    return json({ error: msg }, 500);
  }
});
