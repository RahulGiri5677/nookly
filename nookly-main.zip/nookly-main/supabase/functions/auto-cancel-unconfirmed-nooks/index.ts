// All time comparisons are server UTC only
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ─── Tone constants (mirrored from src/constants/notificationContent.ts) ──────
const NOTIFICATIONS = {
  nookAutoCancelled: {
    title: "This one didn't gather today",
    body: (topic: string) =>
      `"${topic}" didn't reach enough people this time. No worries — you can always raise it again 🌙`,
  },
} as const;

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function logCron(
  admin: ReturnType<typeof createClient>,
  jobName: string,
  ranAt: string,
  result: Record<string, unknown>,
) {
  try {
    await admin.from("system_cron_logs").insert({ job_name: jobName, ran_at: ranAt, result });
  } catch (e) {
    console.error("Failed to write cron log:", e);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey  = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const admin       = createClient(supabaseUrl, serviceKey);

  const jobStart = new Date().toISOString();
  let result: Record<string, unknown> = {};

  try {
    const nowUtc = new Date().toISOString();

    // Fetch pending nooks whose start time has passed and haven't been auto-cancelled yet
    const { data: nooks, error: nooksError } = await admin
      .from("nooks")
      .select("id, topic, host_id, date_time, min_people, current_people")
      .eq("status", "pending")
      .eq("auto_cancelled", false)
      .is("cancelled_at", null)
      .lt("date_time", nowUtc);

    if (nooksError) {
      console.error("Failed to fetch pending nooks:", nooksError.message);
      result = { error: "Failed to fetch nooks" };
      await logCron(admin, "nook-auto-cancel", jobStart, result);
      return json({ error: "Failed to fetch nooks" }, 500);
    }

    let cancelledCount = 0;
    let skippedCount   = 0;

    for (const nook of nooks || []) {
      // Only cancel if below minimum (extra idempotency guard)
      if (nook.current_people >= nook.min_people) {
        skippedCount++;
        continue;
      }

      // Atomic update — only succeeds if still pending and not yet auto_cancelled
      const { error: cancelError } = await admin
        .from("nooks")
        .update({
          status:         "cancelled",
          cancelled_at:   nowUtc,
          cancelled_by:   null,
          auto_cancelled: true,
        })
        .eq("id", nook.id)
        .eq("status", "pending")
        .eq("auto_cancelled", false);

      if (cancelError) {
        console.error(`Failed to cancel nook ${nook.id}:`, cancelError.message);
        skippedCount++;
        continue;
      }

      // Notify all approved and pending members
      const { data: members, error: membersError } = await admin
        .from("nook_members")
        .select("user_id")
        .eq("nook_id", nook.id)
        .in("status", ["approved", "pending"]);

      if (membersError) {
        console.error(`Failed to fetch members for nook ${nook.id}:`, membersError.message);
        cancelledCount++;
        continue;
      }

      if (members?.length) {
        const tone = NOTIFICATIONS.nookAutoCancelled;
        const notifications = members.map((m) => ({
          user_id:    m.user_id,
          title:      tone.title,
          message:    tone.body(nook.topic),
          type:       "auto_cancelled",
          nook_id:    nook.id,
          nook_title: nook.topic,
        }));

        const { error: notifError } = await admin.from("notifications").insert(notifications);
        if (notifError) {
          console.error(`Failed to insert notifications for nook ${nook.id}:`, notifError.message);
        }
      }

      cancelledCount++;
      console.log(
        `Auto-cancelled nook "${nook.topic}" (${nook.id}) — ` +
        `${nook.current_people}/${nook.min_people} people — ` +
        `${members?.length ?? 0} members notified`,
      );
    }

    console.log(`auto-cancel-unconfirmed-nooks complete — cancelled: ${cancelledCount}, skipped: ${skippedCount}`);
    result = { success: true, cancelledCount, skippedCount };
    await logCron(admin, "nook-auto-cancel", jobStart, result);
    return json(result);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("auto-cancel-unconfirmed-nooks error:", msg);
    result = { error: msg };
    await logCron(admin, "nook-auto-cancel", jobStart, result);
    return json({ error: "Something went quiet on our end. Try again in a moment 🌿" }, 500);
  }
});
