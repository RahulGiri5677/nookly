import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return json({ error: "Unauthorized" }, 401);
    }
    const userId = claimsData.claims.sub as string;

    const body = await req.json();
    const { nook_id, attendances } = body;

    if (!nook_id || !Array.isArray(attendances)) {
      return json({ error: "Something looks off with that request 🌿" }, 400);
    }

    const admin = createClient(supabaseUrl, serviceKey);

    const { data: nook, error: nookError } = await admin
      .from("nooks")
      .select("host_id, topic, date_time, duration_minutes")
      .eq("id", nook_id)
      .maybeSingle();

    if (nookError || !nook) {
      return json({ error: "Nook not found 🌙" }, 404);
    }

    if (nook.host_id !== userId) {
      return json({ error: "Only the host can mark attendance 🌿" }, 403);
    }

    const startTime = new Date(nook.date_time).getTime();
    const endTime = startTime + (nook.duration_minutes || 60) * 60 * 1000;
    const graceEnd = endTime + 6 * 60 * 60 * 1000;
    const now = Date.now();

    if (now < startTime || now > graceEnd) {
      return json({ error: "Attendance can only be marked during or shortly after the meetup 🌙" }, 400);
    }

    for (const a of attendances) {
      if (!a.user_id || !["attended", "no_show"].includes(a.status)) {
        return json({ error: "Each entry needs a user and a status 🌿" }, 400);
      }
    }

    // Upsert attendance records
    for (const a of attendances) {
      const { error } = await admin.from("attendance").upsert(
        {
          nook_id,
          user_id: a.user_id,
          status: a.status,
          marked_by: userId,
          marked_at: new Date().toISOString(),
          scanned_at: new Date().toISOString(),
        },
        { onConflict: "nook_id,user_id" }
      );
      if (error) {
        console.error("Attendance upsert error:", error.message);
      }
    }

    // Recalculate profile counters from attendance table (single source of truth)
    const affectedUserIds = [...new Set(attendances.map((a: { user_id: string }) => a.user_id))];
    for (const uid of affectedUserIds) {
      const [{ count: attendedCount }, { count: noShowCount }, { count: hostNoShowCount }] = await Promise.all([
        admin.from("attendance").select("id", { count: "exact", head: true }).eq("user_id", uid).eq("status", "attended"),
        admin.from("attendance").select("id", { count: "exact", head: true }).eq("user_id", uid).in("status", ["no_show", "host_no_show"]),
        admin.from("attendance").select("id", { count: "exact", head: true }).eq("user_id", uid).eq("status", "host_no_show"),
      ]);
      await admin.from("profiles").update({
        meetups_attended: attendedCount ?? 0,
        no_shows: noShowCount ?? 0,
        host_no_shows: hostNoShowCount ?? 0,
      }).eq("user_id", uid);
    }

    // Create attendance notifications
    const notifications = attendances.map((a: { user_id: string; status: string }) => ({
      user_id: a.user_id,
      title: a.status === "attended" ? "Glad you showed up 🌿" : "We missed you 🌿",
      message:
        a.status === "attended"
          ? `Your presence at "${nook.topic}" has been noted. Circles feel better when people truly show up ✨`
          : `You weren't there for "${nook.topic}". Showing up consistently builds your trust circle 🌙`,
      type: a.status === "attended" ? "attendance" : "no_show",
      nook_id,
      nook_title: nook.topic || "",
    }));

    await admin.from("notifications").insert(notifications);

    // First-time no-show: extra gentle nudge
    for (const a of attendances) {
      if (a.status === "no_show") {
        const { count } = await admin
          .from("attendance")
          .select("id", { count: "exact", head: true })
          .eq("user_id", a.user_id)
          .eq("status", "no_show");

        if (count === 1) {
          await admin.from("notifications").insert({
            user_id: a.user_id,
            title: "Life happens 🌙",
            message: `Looks like you missed "${nook.topic}". It's okay — just update your status next time so no one waits for you 🤍`,
            type: "nudge",
            nook_id,
            nook_title: nook.topic || "",
          });
        }
      }
    }

    // Feedback request for attendees
    const feedbackNotifications = attendances
      .filter((a: { status: string }) => a.status === "attended")
      .map((a: { user_id: string }) => ({
        user_id: a.user_id,
        title: "How did it feel? 🌙",
        message: `If you'd like, leave a small reflection about "${nook.topic}". Even a few words matter 🤍`,
        type: "feedback",
        nook_id,
        nook_title: nook.topic || "",
      }));

    if (feedbackNotifications.length > 0) {
      await admin.from("notifications").insert(feedbackNotifications);
    }

    return json({ success: true });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("mark-attendance error:", msg);
    return json({ error: "Something went quiet on our end. Try again in a moment 🌿" }, 500);
  }
});
