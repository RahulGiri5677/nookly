// All time comparisons are server UTC only
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version, x-internal-secret",
};

// ─── Brand constants ──────────────────────────────────────────────────────────
const BRAND_COLOR = "#2E7D6B";
const LOGO_URL = "https://nookly.me/nook-icon.svg";
const EMAIL_FROM = "Team Nook <hello@nookly.me>";

function logo(): string {
  return `
    <div style="text-align: center; margin-bottom: 40px;">
      <img src="${LOGO_URL}" alt="Nook" width="48" height="48" style="display: inline-block;" />
      <p style="font-size: 13px; letter-spacing: 0.08em; color: ${BRAND_COLOR}; margin: 8px 0 0; font-weight: 600; text-transform: uppercase;">Nook</p>
    </div>
  `;
}

function divider(): string {
  return `<hr style="border: none; border-top: 1px solid #f0f0f0; margin: 32px 0;" />`;
}

function wrap(bodyContent: string): string {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head><meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /></head>
    <body style="margin: 0; padding: 0; background-color: #fafaf8;">
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 480px; margin: 0 auto; padding: 48px 24px 40px; color: #1a1a1a; background-color: #ffffff;">
        ${logo()}
        ${bodyContent}
        ${divider()}
        <p style="font-size: 13px; line-height: 1.8; color: #999; margin: 0;">— Team Nook 💛</p>
        <p style="font-size: 12px; line-height: 1.8; color: #bbb; margin: 8px 0 0;">You're receiving this because you have a Nook account.</p>
      </div>
    </body>
    </html>
  `;
}

function para(text: string): string {
  return `<p style="font-size: 15px; line-height: 1.9; color: #444; margin: 0 0 16px;">${text}</p>`;
}

function buildWelcomeEmail(firstName: string): string {
  return wrap(`
    ${para(`Hi ${firstName},`)}
    ${para("Nook is a small place for real-world circles.")}
    ${para("No pressure. No noise. Just calm meetups in public spaces.")}
    ${para("You can join one.")}
    ${para("Or raise your own.")}
    ${para("Take your time exploring 🤍")}
  `);
}

const WELCOME_SUBJECT = "Welcome to Nook 🌙";

async function sendEmail(
  to: string,
  subject: string,
  html: string,
  adminClient: ReturnType<typeof createClient>,
  userId: string,
): Promise<boolean> {
  const resendKey = Deno.env.get("RESEND_API_KEY");
  if (!resendKey) {
    console.error("RESEND_API_KEY not configured");
    return false;
  }

  let status = "failed";
  let errorMessage: string | null = null;
  let providerResponse: unknown = null;

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendKey}`,
      },
      body: JSON.stringify({
        from: EMAIL_FROM,
        to: [to],
        subject,
        html,
      }),
    });

    const body = await res.json();
    // Truncate provider response if too large (>5KB)
    const raw = JSON.stringify(body);
    providerResponse = raw.length > 5120 ? { truncated: true, preview: raw.slice(0, 200) } : body;

    if (res.ok) {
      status = "sent";
      console.log(`Welcome email sent to ${to}`);
    } else {
      errorMessage = JSON.stringify(body).slice(0, 500);
      console.error(`Resend error for ${to}:`, body);
    }
  } catch (err) {
    errorMessage = err instanceof Error ? err.message : String(err);
    console.error(`Failed to send welcome email to ${to}:`, err);
  }

  try {
    await adminClient.from("email_logs").insert({
      recipient: to,
      email_type: "welcome",
      status,
      error_message: errorMessage,
      provider_response: providerResponse as Record<string, unknown>,
    });
  } catch (logErr) {
    console.error("Failed to log email:", logErr);
  }

  return status === "sent";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const jsonResp = (data: unknown, statusCode = 200) =>
    new Response(JSON.stringify(data), {
      status: statusCode,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  // ─── Security model ───────────────────────────────────────────────────────────
  // No x-internal-secret required. Security is enforced by:
  //   1. user_id must resolve to a real auth.users email via Admin API (no injection possible)
  //   2. Idempotency: only one welcome email per verified recipient, ever
  //   3. Function sends to the auth-verified email, not a caller-supplied address


  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const adminClient = createClient(supabaseUrl, serviceKey);

    const body = await req.json();
    const { user_id, first_name } = body;

    if (!user_id) {
      return jsonResp({ error: "user_id is required" }, 400);
    }

    // Fetch user email from auth
    const { data: userData, error: userError } = await adminClient.auth.admin.getUserById(user_id);

    if (userError || !userData?.user?.email) {
      console.warn(`No email found for user ${user_id}, skipping welcome email`);
      return jsonResp({ success: true, skipped: true, reason: "no_email" });
    }

    const email = userData.user.email;
    const firstName =
      first_name ||
      userData.user.user_metadata?.display_name ||
      userData.user.user_metadata?.full_name ||
      "there";

    // Idempotency check using actual email (the only correct check)
    const { data: existingEmailLog } = await adminClient
      .from("email_logs")
      .select("id")
      .eq("recipient", email)
      .eq("email_type", "welcome")
      .eq("status", "sent")
      .limit(1)
      .maybeSingle();

    if (existingEmailLog) {
      console.log(`Welcome email already sent to ${email}, skipping`);
      return jsonResp({ success: true, skipped: true, reason: "already_sent" });
    }

    const html = buildWelcomeEmail(firstName);
    const sent = await sendEmail(email, WELCOME_SUBJECT, html, adminClient, user_id);

    return jsonResp({ success: true, sent, email });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("send-welcome-email error:", msg);
    // Fail silently — never block profile creation
    return jsonResp({ success: true, error: msg });
  }
});
