// All time comparisons are server UTC only
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ─── Brand constants ──────────────────────────────────────────────────────────
const BRAND_COLOR = "#2E7D6B";
const LOGO_URL = "https://nookly.me/nook-icon.svg";
const EMAIL_FROM = "Team Nook <hello@nookly.me>";

function logo(): string {
  return `
    <div style="text-align: center; margin-bottom: 40px;">
      <img src="${LOGO_URL}" alt="Nook" width="48" height="48" style="display: inline-block;" />
      <p style="font-size: 13px; letter-spacing: 0.08em; color: ${BRAND_COLOR}; margin: 8px 0 0; font-weight: 600; text-transform: uppercase;">Nook</p>
    </div>
  `;
}

function divider(): string {
  return `<hr style="border: none; border-top: 1px solid #f0f0f0; margin: 32px 0;" />`;
}

function wrap(bodyContent: string): string {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head><meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /></head>
    <body style="margin: 0; padding: 0; background-color: #fafaf8;">
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 480px; margin: 0 auto; padding: 48px 24px 40px; color: #1a1a1a; background-color: #ffffff;">
        ${logo()}
        ${bodyContent}
        ${divider()}
        <p style="font-size: 13px; line-height: 1.8; color: #999; margin: 0;">— Team Nook 💛</p>
        <p style="font-size: 12px; line-height: 1.8; color: #bbb; margin: 8px 0 0;">You're receiving this because you have a Nook account.</p>
      </div>
    </body>
    </html>
  `;
}

function para(text: string): string {
  return `<p style="font-size: 15px; line-height: 1.9; color: #444; margin: 0 0 16px;">${text}</p>`;
}

function buildCancellationEmail(
  firstName: string,
  meetupTitle: string,
  dateStr: string,
  timeStr: string
): string {
  return wrap(`
    ${para(`Hi ${firstName},`)}
    ${para("Just a small update —")}
    ${para(`<strong>"${meetupTitle}"</strong> that was planned for <strong>${dateStr}</strong> at <strong>${timeStr}</strong> won't be happening this time.`)}
    ${para("The host had to cancel.")}
    ${para("Nothing is needed from your side.")}
    ${para("You can explore another Nook whenever it feels right 🤍")}
  `);
}

async function sendEmail(to: string, subject: string, html: string) {
  const resendKey = Deno.env.get("RESEND_API_KEY");
  if (!resendKey) {
    console.error("RESEND_API_KEY not configured");
    return;
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendKey}`,
      },
      body: JSON.stringify({
        from: EMAIL_FROM,
        to: [to],
        subject,
        html,
      }),
    });
    const body = await res.text();
    if (!res.ok) {
      console.error(`Resend error for ${to}: ${body}`);
    } else {
      console.log(`Cancellation email sent to ${to}`);
    }
  } catch (err) {
    console.error(`Failed to send email to ${to}:`, err);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = claimsData.claims.sub as string;

    const { nook_id } = await req.json();
    if (!nook_id) {
      return new Response(JSON.stringify({ error: "nook_id required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    const { data: nook, error: nookError } = await adminClient
      .from("nooks")
      .select("*")
      .eq("id", nook_id)
      .single();

    if (nookError || !nook) {
      return new Response(JSON.stringify({ error: "Nook not found 🌙" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (nook.host_id !== userId) {
      return new Response(JSON.stringify({ error: "Only the host can cancel this Nook 🌿" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (nook.status === "cancelled") {
      return new Response(JSON.stringify({ error: "This Nook has already been cancelled 🌙" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ── Server-side cancel lock: T-10h enforcement ────────────────────────
    const nowUtc = Date.now();
    const startTime = new Date(nook.date_time).getTime();
    const hoursUntilStart = (startTime - nowUtc) / (1000 * 60 * 60);

    if (hoursUntilStart <= 10 && hoursUntilStart > 0) {
      return new Response(
        JSON.stringify({ error: "This Nook is too close to start time to cancel now 🌙" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    // ─────────────────────────────────────────────────────────────────────

    // Cancel the nook
    const { error: updateError } = await adminClient
      .from("nooks")
      .update({
        status: "cancelled",
        cancelled_at: new Date().toISOString(),
        cancelled_by: userId,
      })
      .eq("id", nook_id);

    if (updateError) {
      return new Response(JSON.stringify({ error: updateError.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get all approved members
    const { data: members } = await adminClient
      .from("nook_members")
      .select("user_id")
      .eq("nook_id", nook_id)
      .eq("status", "approved");

    const participantIds = (members || []).map((m) => m.user_id);

    // Format date for messages
    const dateObj = new Date(nook.date_time);
    const dateStr = dateObj.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
    });
    const timeStr = dateObj.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
    });

    // In-app notifications for all participants
    if (participantIds.length > 0) {
      const notifications = participantIds.map((uid) => ({
        user_id: uid,
        title: "Plans changed 🌿",
        message: `"${nook.topic}" won't be happening this time. You can explore another circle whenever you're ready 🤍`,
        type: "cancelled",
        nook_id: nook_id,
        nook_title: nook.topic,
      }));

      await adminClient.from("notifications").insert(notifications);
    }

    // Send cancellation emails
    let emailsSent = 0;
    for (const uid of participantIds) {
      try {
        const { data: userData } = await adminClient.auth.admin.getUserById(uid);
        if (userData?.user?.email) {
          const email = userData.user.email;
          const firstName = userData.user.user_metadata?.display_name || "there";

          await sendEmail(
            email,
            "Plans changed for your Nook 🌿",
            buildCancellationEmail(firstName, nook.topic, dateStr, timeStr)
          );
          emailsSent++;
        }
      } catch (err) {
        console.error(`Error sending email to user ${uid}:`, err);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        notified_count: participantIds.length,
        emails_sent: emailsSent,
        message: "This Nook has been cancelled. All participants have been notified.",
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (err) {
    console.error("Error:", err);
    return new Response(JSON.stringify({ error: "Something went quiet on our end 🌿" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
