// All time comparisons are server UTC only
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ─── Tone constants (mirrored from src/constants/notificationContent.ts) ──────
const NOTIFICATIONS = {
  fullAttendance: (topic: string) => ({
    title:   "Glad you showed up 🌿",
    message: `Your presence at "${topic}" has been noted. Circles feel better when people truly show up ✨`,
    type:    "attendance",
  }),
  firstNoShow: (topic: string) => ({
    title:   "Life happens 🌙",
    message: `Looks like you missed "${topic}". It's okay — just update your status next time so no one waits for you 🤍`,
    type:    "nudge",
  }),
  repeatNoShow: (topic: string) => ({
    title:   "We missed you 🌿",
    message: `You weren't there for "${topic}". Showing up consistently builds your trust circle 🌙`,
    type:    "no_show",
  }),
  hostNoShow: (topic: string) => ({
    title:   "Hosting carries weight 🌿",
    message: `"${topic}" didn't have a host present. When you host, others rely on you 🤍`,
    type:    "host_no_show",
  }),
  hostExitMissing: (topic: string) => ({
    title:   "Let's close it properly 🌙",
    message: `The exit scan wasn't completed for "${topic}". Closing the circle fully keeps things smooth for everyone 🤍`,
    type:    "host_no_show",
  }),
  feedbackRequest: (topic: string) => ({
    title:   "How did it feel? 🌙",
    message: `If you'd like, leave a small reflection about "${topic}". Even a few words matter 🤍`,
    type:    "feedback",
  }),
} as const;

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// ─── Credibility weights ──────────────────────────────────────────────────────
const WEIGHT_EXIT_BOOST   =  2;
const WEIGHT_NO_SHOW      = -8;
const WEIGHT_HOST_NO_SHOW = -18;

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

async function adjustCredibility(
  admin: ReturnType<typeof createClient>,
  userId: string,
  delta: number,
): Promise<void> {
  const { data } = await admin
    .from("profiles")
    .select("credibility_score")
    .eq("user_id", userId)
    .single();
  if (!data) return;
  const next = clamp(Number(data.credibility_score ?? 50) + delta, 0, 100);
  await admin.from("profiles").update({ credibility_score: next }).eq("user_id", userId);
}

// Recalculate profile counters from attendance (single source of truth)
async function recalculateProfileCounters(
  admin: ReturnType<typeof createClient>,
  userId: string,
): Promise<void> {
  const [{ count: attended }, { count: noShows }, { count: hostNoShows }] = await Promise.all([
    admin.from("attendance").select("id", { count: "exact", head: true }).eq("user_id", userId).eq("status", "attended"),
    admin.from("attendance").select("id", { count: "exact", head: true }).eq("user_id", userId).in("status", ["no_show", "host_no_show"]),
    admin.from("attendance").select("id", { count: "exact", head: true }).eq("user_id", userId).eq("status", "host_no_show"),
  ]);
  await admin.from("profiles").update({
    meetups_attended: attended ?? 0,
    no_shows: noShows ?? 0,
    host_no_shows: hostNoShows ?? 0,
  }).eq("user_id", userId);
}

async function countRecentExitMisses(
  admin: ReturnType<typeof createClient>,
  userId: string,
): Promise<number> {
  const since = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString();
  const { count } = await admin
    .from("attendance")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId)
    .eq("entry_marked", true)
    .eq("exit_marked", false)
    .gte("created_at", since);
  return count ?? 0;
}

async function logCron(
  admin: ReturnType<typeof createClient>,
  jobName: string,
  ranAt: string,
  result: Record<string, unknown>,
) {
  try {
    await admin.from("system_cron_logs").insert({ job_name: jobName, ran_at: ranAt, result });
  } catch (e) {
    console.error("Failed to write cron log:", e);
  }
}

// ─── Shared notification helper ───────────────────────────────────────────────
async function sendNotification(
  adminClient: ReturnType<typeof createClient>,
  params: {
    user_id: string;
    type: string;
    title: string;
    message: string;
    nook_id: string;
    nook_title: string;
  },
): Promise<void> {
  const { error } = await adminClient.from("notifications").insert({
    user_id:    params.user_id,
    type:       params.type,
    title:      params.title,
    message:    params.message,
    nook_id:    params.nook_id,
    nook_title: params.nook_title,
  });
  if (error) {
    console.error(`Failed to send notification (${params.type}) to ${params.user_id}:`, error.message);
  }
}

// ─── Main handler ─────────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey  = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const admin       = createClient(supabaseUrl, serviceKey);

  const jobStart = new Date().toISOString();
  let result: Record<string, unknown> = {};

  try {
    const nowUtc        = Date.now();
    const gracePeriodMs = 20 * 60 * 1000; // 20 minutes

    // Exclude cancelled nooks explicitly
    const { data: nooks, error: nooksError } = await admin
      .from("nooks")
      .select("id, topic, host_id, date_time, duration_minutes")
      .eq("no_show_processed", false)
      .eq("status", "confirmed")
      .neq("status", "cancelled")
      .is("cancelled_at", null);

    if (nooksError) {
      console.error("Error fetching nooks:", nooksError.message);
      result = { error: "Failed to fetch nooks" };
      await logCron(admin, "nook-auto-mark", jobStart, result);
      return json({ error: "Failed to fetch nooks" }, 500);
    }

    let processed = 0;
    let skipped   = 0;

    for (const nook of nooks || []) {
      const startTime = new Date(nook.date_time).getTime();
      const endTime   = startTime + (nook.duration_minutes || 60) * 60 * 1000;
      const graceEnd  = endTime + gracePeriodMs;

      if (nowUtc <= graceEnd) {
        skipped++;
        continue;
      }

      const { data: members, error: membersError } = await admin
        .from("nook_members")
        .select("user_id")
        .eq("nook_id", nook.id)
        .eq("status", "approved");

      if (membersError || !members?.length) {
        await admin
          .from("nooks")
          .update({ no_show_processed: true, status: "completed" })
          .eq("id", nook.id);
        skipped++;
        continue;
      }

      for (const member of members) {
        const isHost = member.user_id === nook.host_id;

        const { data: att } = await admin
          .from("attendance")
          .select("id, entry_marked, exit_marked, status")
          .eq("nook_id", nook.id)
          .eq("user_id", member.user_id)
          .maybeSingle();

        const entry = !!att?.entry_marked;
        const exit  = !!att?.exit_marked;

        let finalStatus: string;
        if (isHost) {
          finalStatus = (entry && exit) ? "attended" : "host_no_show";
        } else {
          finalStatus = entry ? "attended" : "no_show";
        }

        const wasAlreadyFinal = att?.status === finalStatus;

        if (att) {
          if (!wasAlreadyFinal) {
            await admin
              .from("attendance")
              .update({ status: finalStatus })
              .eq("id", att.id);
          }
        } else {
          await admin.from("attendance").insert({
            nook_id:      nook.id,
            user_id:      member.user_id,
            status:       finalStatus,
            marked_by:    null,
            marked_at:    new Date(nowUtc).toISOString(),
            entry_marked: false,
            exit_marked:  false,
          });
        }

        if (!wasAlreadyFinal) {
          if (finalStatus === "attended") {
            await recalculateProfileCounters(admin, member.user_id);

            if (exit) {
              const exitMisses = await countRecentExitMisses(admin, member.user_id);
              if (exitMisses <= 2) {
                await adjustCredibility(admin, member.user_id, WEIGHT_EXIT_BOOST);
              }

              // AI reflection prompt — soft, one question, human tone
              let reflectionMsg = NOTIFICATIONS.fullAttendance(nook.topic).message;
              try {
                const aiUrl  = `${supabaseUrl}/functions/v1/ai-nook`;
                const apiKey = Deno.env.get("SUPABASE_ANON_KEY")!;
                const ctrl   = new AbortController();
                const t      = setTimeout(() => ctrl.abort(), 5000);
                try {
                  const aiRes = await fetch(aiUrl, {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                      Authorization: `Bearer ${apiKey}`,
                      apikey: apiKey,
                    },
                    body: JSON.stringify({ type: "reflection_prompt" }),
                    signal: ctrl.signal,
                  });
                  if (aiRes.ok) {
                    const aiData = await aiRes.json();
                    if (aiData?.prompt) reflectionMsg = aiData.prompt;
                  }
                } finally {
                  clearTimeout(t);
                }
              } catch {
                // AI failed silently — fallback tone already set
              }

              const fullAttendanceNotif = NOTIFICATIONS.fullAttendance(nook.topic);
              await sendNotification(admin, {
                user_id:    member.user_id,
                type:       fullAttendanceNotif.type,
                title:      fullAttendanceNotif.title,
                message:    reflectionMsg,
                nook_id:    nook.id,
                nook_title: nook.topic || "",
              });
            }

          } else if (finalStatus === "no_show") {
            await recalculateProfileCounters(admin, member.user_id);
            await adjustCredibility(admin, member.user_id, WEIGHT_NO_SHOW);

            const { count: totalNoShows } = await admin
              .from("attendance")
              .select("id", { count: "exact", head: true })
              .eq("user_id", member.user_id)
              .in("status", ["no_show", "host_no_show"]);

            const notif = totalNoShows === 1
              ? NOTIFICATIONS.firstNoShow(nook.topic)
              : NOTIFICATIONS.repeatNoShow(nook.topic);

            await sendNotification(admin, {
              ...notif,
              user_id:    member.user_id,
              nook_id:    nook.id,
              nook_title: nook.topic || "",
            });

          } else if (finalStatus === "host_no_show") {
            await recalculateProfileCounters(admin, member.user_id);
            await adjustCredibility(admin, member.user_id, WEIGHT_HOST_NO_SHOW);

            const notif = entry
              ? NOTIFICATIONS.hostExitMissing(nook.topic)
              : NOTIFICATIONS.hostNoShow(nook.topic);

            await sendNotification(admin, {
              ...notif,
              user_id:    member.user_id,
              nook_id:    nook.id,
              nook_title: nook.topic || "",
            });
          }
        }
      }

      await admin
        .from("nooks")
        .update({ no_show_processed: true, status: "completed" })
        .eq("id", nook.id);

      processed++;
      console.log(`auto-mark-noshow: processed "${nook.topic}" (${nook.id}) — ${members.length} members`);
    }

    console.log(`auto-mark-noshow complete — processed: ${processed}, skipped: ${skipped}`);
    result = { success: true, processed, skipped };
    await logCron(admin, "nook-auto-mark", jobStart, result);
    return json(result);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("auto-mark-noshow error:", msg);
    result = { error: msg };
    await logCron(admin, "nook-auto-mark", jobStart, result);
    return json({ error: "Something went quiet on our end. Please try again in a moment 🌿" }, 500);
  }
});
