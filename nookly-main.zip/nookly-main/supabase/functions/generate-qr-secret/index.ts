import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function hmacSign(secret: string, message: string): Promise<string> {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(message));
  return Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .slice(0, 16); // 16-char hex prefix for compact signature
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "Unauthorized" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) return json({ error: "Unauthorized" }, 401);

    const body = await req.json();
    const { nook_id, phase } = body;

    if (!nook_id || typeof nook_id !== "string") return json({ error: "Invalid input" }, 400);

    // phase must be "entry" or "exit"
    const scanPhase: "entry" | "exit" = phase === "exit" ? "exit" : "entry";

    const adminClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // Verify caller is the host
    const { data: nook, error: nookError } = await adminClient
      .from("nooks")
      .select("host_id, date_time, duration_minutes")
      .eq("id", nook_id)
      .maybeSingle();

    if (nookError || !nook) return json({ error: "Nook not found" }, 404);
    if (nook.host_id !== user.id) return json({ error: "Only the host can generate QR tokens" }, 403);

    const signingSecret = Deno.env.get("QR_SIGNING_SECRET");
    if (!signingSecret) return json({ error: "Server configuration error" }, 500);

    // Validate time window before generating (server UTC)
    const nowUtc = Date.now();
    const startTime = new Date(nook.date_time).getTime();
    const durationMs = (nook.duration_minutes || 60) * 60 * 1000;
    const endTime = startTime + durationMs;

    // Entry window: T-15 to T+15 min
    const entryStart = startTime - 15 * 60 * 1000;
    const entryEnd   = startTime + 15 * 60 * 1000;

    // Exit window: T(end)-15 to T(end)+15 min
    const exitStart = endTime - 15 * 60 * 1000;
    const exitEnd   = endTime + 15 * 60 * 1000;

    if (scanPhase === "entry" && (nowUtc < entryStart || nowUtc > entryEnd)) {
      return json({ error: "Entry QR is not active yet or has expired", phase: scanPhase }, 400);
    }
    if (scanPhase === "exit" && (nowUtc < exitStart || nowUtc > exitEnd)) {
      return json({ error: "Exit QR is not active yet or has expired", phase: scanPhase }, 400);
    }

    // ── Auto-mark host attendance (idempotent) ────────────────────────────────
    //
    // When the host activates Host Anchor Mode in the entry window, their own
    // attendance entry is created server-side. This prevents the auto-mark-noshow
    // cron from misclassifying an active host as host_no_show.
    //
    // Rules:
    //   • Only triggered when phase === "entry"
    //   • Never overwrites exit_marked if already set
    //   • Idempotent: safe to call multiple times (60-second token refresh)
    // ─────────────────────────────────────────────────────────────────────────
    if (scanPhase === "entry") {
      const nowIso = new Date(nowUtc).toISOString();

      // Check existing record to preserve exit state
      const { data: existing } = await adminClient
        .from("attendance")
        .select("id, entry_marked, exit_marked")
        .eq("nook_id", nook_id)
        .eq("user_id", user.id)
        .maybeSingle();

      if (!existing) {
        // No record yet — create one
        await adminClient.from("attendance").insert({
          nook_id,
          user_id:      user.id,
          entry_marked: true,
          entry_time:   nowIso,
          exit_marked:  false,
          status:       "attended",
          marked_by:    user.id,
          marked_at:    nowIso,
        });
      } else if (!existing.entry_marked) {
        // Record exists but entry not yet marked — update only entry fields
        await adminClient
          .from("attendance")
          .update({
            entry_marked: true,
            entry_time:   nowIso,
            status:       "attended",
          })
          .eq("id", existing.id);
      }
      // If entry_marked already true: no-op (idempotent)
    }

    // Build signed token
    const issuedAt  = nowUtc;
    const expiresAt = issuedAt + 60 * 1000; // 60 seconds
    const payload   = `${nook_id}:${scanPhase}:${issuedAt}`;
    const signature = await hmacSign(signingSecret, payload);

    const token = {
      nook_id,
      phase:     scanPhase,
      issued_at: issuedAt,
      expires_at: expiresAt,
      signature,
    };

    // Store compact token in qr_secret for legacy display fallback
    const tokenStr = JSON.stringify(token);
    await adminClient
      .from("nooks")
      .update({ qr_secret: tokenStr })
      .eq("id", nook_id);

    return json({ token, secret: signature }); // secret = short display code
  } catch (err) {
    console.error("generate-qr-secret error:", err);
    return json({ error: "Internal error" }, 500);
  }
});
