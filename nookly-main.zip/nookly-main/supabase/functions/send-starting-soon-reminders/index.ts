// All time comparisons are server UTC only
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// ─── Tone constants (mirrored from src/constants/notificationContent.ts) ──────
const NOTIFICATIONS = {
  startingSoon: {
    title: "See you soon 🌿",
    body: (topic: string) =>
      `"${topic}" begins in a couple of hours. Take your time getting there 🤍`,
  },
} as const;

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// ─── Shared notification helper ───────────────────────────────────────────────
async function sendNotification(
  adminClient: ReturnType<typeof createClient>,
  params: {
    user_id: string;
    type: string;
    title: string;
    message: string;
    nook_id: string;
    nook_title: string;
  },
): Promise<{ error: string | null }> {
  const { error } = await adminClient.from("notifications").insert({
    user_id: params.user_id,
    type: params.type,
    title: params.title,
    message: params.message,
    nook_id: params.nook_id,
    nook_title: params.nook_title,
  });
  return { error: error?.message ?? null };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const admin = createClient(supabaseUrl, serviceKey);

  const jobStart = new Date().toISOString();
  let result: Record<string, unknown> = {};

  try {
    // Window: nooks starting between now+1h55m and now+2h05m (±5 min tolerance)
    const nowMs = Date.now();
    const windowStart = new Date(nowMs + (1 * 60 + 55) * 60 * 1000).toISOString();
    const windowEnd   = new Date(nowMs + (2 * 60 + 5) * 60 * 1000).toISOString();

    const { data: nooks, error: nooksError } = await admin
      .from("nooks")
      .select("id, topic, date_time, host_id, reminder_sent")
      .eq("status", "confirmed")
      .eq("reminder_sent", false)
      .gte("date_time", windowStart)
      .lte("date_time", windowEnd);

    if (nooksError) {
      console.error("Failed to fetch nooks for reminders:", nooksError.message);
      result = { error: "Failed to fetch nooks", remindedCount: 0, skippedCount: 0 };
      await logCron(admin, "nook-reminders", jobStart, result);
      return json({ error: "Failed to fetch nooks" }, 500);
    }

    let remindedCount = 0;
    let skippedCount = 0;

    for (const nook of nooks || []) {
      const { data: members, error: membersError } = await admin
        .from("nook_members")
        .select("user_id")
        .eq("nook_id", nook.id)
        .eq("status", "approved");

      if (membersError || !members?.length) {
        skippedCount++;
        continue;
      }

      const tone = NOTIFICATIONS.startingSoon;
      const notifications = members.map((m) => ({
        user_id:    m.user_id,
        title:      tone.title,
        message:    tone.body(nook.topic),
        type:       "reminder",
        nook_id:    nook.id,
        nook_title: nook.topic,
      }));

      const { error: notifError } = await admin.from("notifications").insert(notifications);

      if (notifError) {
        console.error(`Failed to insert notifications for nook ${nook.id}:`, notifError.message);
        skippedCount++;
        continue;
      }

      const { error: updateError } = await admin
        .from("nooks")
        .update({ reminder_sent: true })
        .eq("id", nook.id);

      if (updateError) {
        console.error(`Failed to mark nook ${nook.id} as reminded:`, updateError.message);
      } else {
        remindedCount++;
        console.log(`Reminder sent for nook "${nook.topic}" (${nook.id}) — ${members.length} members`);
      }
    }

    console.log(`send-starting-soon-reminders complete — reminded: ${remindedCount}, skipped: ${skippedCount}`);
    result = { success: true, remindedCount, skippedCount };
    await logCron(admin, "nook-reminders", jobStart, result);
    return json(result);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("send-starting-soon-reminders error:", msg);
    result = { error: msg };
    await logCron(admin, "nook-reminders", jobStart, result);
    return json({ error: "Something went quiet on our end. Try again in a moment 🌿" }, 500);
  }
});

async function logCron(
  admin: ReturnType<typeof createClient>,
  jobName: string,
  ranAt: string,
  result: Record<string, unknown>,
) {
  try {
    await admin.from("system_cron_logs").insert({ job_name: jobName, ran_at: ranAt, result });
  } catch (e) {
    console.error("Failed to write cron log:", e);
  }
}
