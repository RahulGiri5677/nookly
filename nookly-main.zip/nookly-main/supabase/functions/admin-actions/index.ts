import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

async function sendEmail(
  adminClient: any,
  to: string,
  subject: string,
  html: string,
  emailType: string = "unknown",
) {
  const resendKey = Deno.env.get("RESEND_API_KEY");
  if (!resendKey) {
    await logEmail(adminClient, emailType, to, "failed", "RESEND_API_KEY not configured", null);
    return { success: false, error: "RESEND_API_KEY not configured" };
  }
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendKey}`,
      },
      body: JSON.stringify({
        from: "Nook <onboarding@resend.dev>",
        to: [to],
        subject,
        html,
      }),
    });
    const body = await res.json();
    if (!res.ok) {
      const errMsg = typeof body === "object" ? JSON.stringify(body) : String(body);
      await logEmail(adminClient, emailType, to, "failed", errMsg, body);
      return { success: false, error: body };
    }
    await logEmail(adminClient, emailType, to, "sent", null, body);
    return { success: true, data: body };
  } catch (err) {
    const errMsg = String(err);
    await logEmail(adminClient, emailType, to, "failed", errMsg, null);
    return { success: false, error: errMsg };
  }
}

async function logEmail(
  adminClient: any,
  emailType: string,
  recipient: string,
  status: string,
  errorMessage: string | null,
  providerResponse: any,
) {
  try {
    await adminClient.from("email_logs").insert({
      email_type: emailType,
      recipient,
      status,
      error_message: errorMessage,
      provider_response: providerResponse,
    });
  } catch (e) {
    console.error("Failed to log email:", e);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(token);
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const userId = claimsData.claims.sub as string;

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    // Verify admin role
    const { data: roleData } = await adminClient
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();

    if (!roleData) {
      return new Response(JSON.stringify({ error: "Forbidden: Admin only" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const { action } = body;

    // Log admin action
    await adminClient.from("admin_logs").insert({
      admin_user_id: userId,
      action,
      details: body,
    });

    switch (action) {
      case "add_dummy_participant": {
        const { nook_id } = body;
        const { data: nookData } = await adminClient
          .from("nooks")
          .select("current_people, max_people, min_people, status")
          .eq("id", nook_id)
          .single();
        if (!nookData) return jsonResponse({ error: "Nook not found" });
        if (nookData.current_people >= nookData.max_people) return jsonResponse({ error: "Nook is already full" });
        const newCount = nookData.current_people + 1;
        const updates: Record<string, unknown> = { current_people: newCount };
        if (newCount >= nookData.min_people && nookData.status === "pending") {
          updates.status = "confirmed";
        }
        await adminClient.from("nooks").update(updates).eq("id", nook_id);
        return jsonResponse({ success: true, current_people: newCount });
      }

      case "remove_participant": {
        const { nook_id, user_id } = body;
        await adminClient.from("nook_members").delete().eq("nook_id", nook_id).eq("user_id", user_id);
        const { data: nook } = await adminClient.from("nooks").select("current_people").eq("id", nook_id).single();
        if (nook) {
          await adminClient.from("nooks").update({ current_people: Math.max(1, nook.current_people - 1) }).eq("id", nook_id);
        }
        return jsonResponse({ success: true });
      }

      case "mark_attendance": {
        const { nook_id, user_id, status } = body;
        const { error } = await adminClient.from("attendance").upsert(
          { nook_id, user_id, status, marked_at: new Date().toISOString(), marked_by: userId },
          { onConflict: "nook_id,user_id" }
        );
        if (error) throw error;
        return jsonResponse({ success: true });
      }

      case "reset_attendance": {
        const { nook_id } = body;
        await adminClient.from("attendance").delete().eq("nook_id", nook_id);
        return jsonResponse({ success: true });
      }

      case "update_nook_time": {
        const { nook_id, new_date_time } = body;
        await adminClient.from("nooks").update({ date_time: new_date_time }).eq("id", nook_id);
        return jsonResponse({ success: true });
      }

      case "update_nook_status": {
        const { nook_id, status } = body;
        const updates: Record<string, unknown> = { status };
        if (status === "cancelled") {
          updates.cancelled_at = new Date().toISOString();
          updates.cancelled_by = userId;
        }
        await adminClient.from("nooks").update(updates).eq("id", nook_id);
        return jsonResponse({ success: true });
      }

      case "trigger_notification": {
        const { target_user_id, title, message, type, nook_id, nook_title } = body;
        await adminClient.from("notifications").insert({
          user_id: target_user_id || userId,
          title,
          message,
          type: type || "update",
          nook_id: nook_id || null,
          nook_title: nook_title || null,
        });
        return jsonResponse({ success: true });
      }

      case "send_test_email": {
        const { to, subject, html } = body;
        const result = await sendEmail(adminClient, to, subject, html, "test_email");
        return jsonResponse(result);
      }

      case "get_email_logs": {
        const { data: logs } = await adminClient
          .from("email_logs")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(20);
        return jsonResponse({ logs: logs || [] });
      }

      case "update_no_shows": {
        const { target_user_id, no_shows, meetups_attended } = body;
        const updates: Record<string, unknown> = {};
        if (no_shows !== undefined) updates.no_shows = no_shows;
        if (meetups_attended !== undefined) updates.meetups_attended = meetups_attended;
        await adminClient.from("profiles").update(updates).eq("user_id", target_user_id);
        return jsonResponse({ success: true });
      }

      case "reset_nook": {
        const { nook_id } = body;
        await adminClient.from("nooks").update({
          status: "pending",
          current_people: 1,
          cancelled_at: null,
          cancelled_by: null,
        }).eq("id", nook_id);
        const { data: nook } = await adminClient.from("nooks").select("host_id").eq("id", nook_id).single();
        if (nook) {
          await adminClient.from("nook_members").delete().eq("nook_id", nook_id).neq("user_id", nook.host_id);
        }
        await adminClient.from("attendance").delete().eq("nook_id", nook_id);
        return jsonResponse({ success: true });
      }

      case "get_nook_snapshot": {
        const { nook_id } = body;
        const { data: nook } = await adminClient.from("nooks").select("*").eq("id", nook_id).single();
        const { data: members } = await adminClient.from("nook_members").select("*").eq("nook_id", nook_id);
        const { data: attendance } = await adminClient.from("attendance").select("*").eq("nook_id", nook_id);
        const { data: notifications } = await adminClient.from("notifications").select("*").eq("nook_id", nook_id).order("created_at", { ascending: false }).limit(20);
        return jsonResponse({ nook, members, attendance, notifications });
      }

      case "get_admin_logs": {
        const { data: logs } = await adminClient.from("admin_logs").select("*").order("created_at", { ascending: false }).limit(50);
        return jsonResponse({ logs });
      }

      case "archive_nook": {
        const { nook_id } = body;
        await adminClient.from("nooks").update({
          status: "cancelled",
          cancelled_at: new Date().toISOString(),
          cancelled_by: userId,
        }).eq("id", nook_id);
        return jsonResponse({ success: true });
      }

      case "delete_nook": {
        const { nook_id } = body;
        // Delete related records first
        await adminClient.from("attendance").delete().eq("nook_id", nook_id);
        await adminClient.from("nook_members").delete().eq("nook_id", nook_id);
        await adminClient.from("notifications").delete().eq("nook_id", nook_id);
        await adminClient.from("feedback").delete().eq("nook_id", nook_id);
        await adminClient.from("reports").delete().eq("nook_id", nook_id);
        await adminClient.from("nooks").delete().eq("id", nook_id);
        return jsonResponse({ success: true });
      }

      default:
        return new Response(JSON.stringify({ error: `Unknown action: ${action}` }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : (typeof err === "object" ? JSON.stringify(err) : String(err));
    console.error("Admin action error:", errorMsg);
    return new Response(JSON.stringify({ error: errorMsg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

function jsonResponse(data: unknown) {
  return new Response(JSON.stringify(data), {
    status: 200,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
